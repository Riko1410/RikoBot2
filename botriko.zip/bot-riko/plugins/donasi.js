let handler = async m => m.reply(`
╭─「 Donasi • Gopay-Pulsa 」
│ • Gopay [082260230156]
│ • Telkomsel [082260230156]
╰────
`.trim(Makasih Yang Sudah Donasi🙏)) // Tambah sendiri kalo mau
handler.help = ['donasi']
handler.tags = ['info']
handler.command = /^dona(te|si)$/i

module.exports = handler
